! ------------------------------------------------------------------------------
!
!                       THE ECONOMICS OF WOMEN'S RIGHTS  
!
! ------------------------------------------------------------------------------
!
! by Michèle Tertilt, Matthias Doepke, Anne Hannusch and Laura Montenbruck
!
! This version: 2022-11-28
!
! To replicate the results, please run all files in 'ReplicationPackage/code/'.
! The results will be saved in 'ReplicationPackage/output/'.
! To look at the results, go to 'ReplicationPackage/output/pdf' and compile
! the LaTex file 'empirical_results_JEEA.tex'.
!
!
!   (1) DESCRIPTIVE AND REGRESSION RESULTS: Run
! 
! -  ReplicationPackage/code/1_Analysis.do
!        - Input file: ReplicationPackage/data/final_data.dta
! 	 - Output files: All files are saved in ReplicationPackage/output/tables
!             
!
!   (2) FIGURES: Run
!
! - ReplicationPackage/code/2_DataForFigures.do to prepare the input files for figures
!
! - Figure 1: ReplicationPackage/code/3_Figure1.R
!       - Input file: ReplicationPackage/output/figures/Overall_Index.txt
!
! - Figure 3: ReplicationPackage/code/4_Figure3.R 
!       - Input file: ReplicationPackage/output/figures/IndicesOverTime.txt
!
! - Figure 4: ReplicationPackage/code/5_Figure4.R
!       - Input file: ReplicationPackage/output/figures/Overall_Index.txt
!
! - Output files: All resulting figures are saved in 
!         'ReplicationPackage/output/figures' as PDF or .tex files            
!
! ------------------------------------------------------------------------------