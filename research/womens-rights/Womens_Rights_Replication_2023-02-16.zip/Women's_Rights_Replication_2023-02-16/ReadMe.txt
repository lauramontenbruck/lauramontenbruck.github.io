! ------------------------------------------------------------------------------
!
!                 THE ECONOMICS OF WOMEN'S RIGHTS - Extended Data Set
!
! ------------------------------------------------------------------------------
!
! by Michèle Tertilt, Matthias Doepke, Anne Hannusch and Laura Montenbruck
!
! This version: 2023-01-23
!
! This package provides an extended data set that can be used to expand the
! analysis in ``The Economic of Women's Rights", Journal of the European
! Economic Association, Volume 20, Issue 6, December 2022, p. 2271–2316, 
! https://doi.org/10.1093/jeea/jvac059
! It also provides the code to merge all original datasets and generate the
! relevant variables as well as the final dataset.
!
! Final output was generated using Stata version Stata/SE 17.0 and R version 4.1.2.
!
! Summary of extensions and changes relative to the JEEA dataset:
!
! - Improvement in the matching of countries across data sets (in 1_Data_preparation.do)
! - Re-coding of female suffrage indicator such that previously missing observations 
!   between 1971 and 1991 are now replaced with values (0/1), in particular for
!   countries formerly belonging to USSR or Yugoslavia.
! - Imputation of dummy variable for religious majorities between 2013-2019
! - Expansion of indicator variable for year of independence 
! - Correction of indicator that summarizes whether contraceptive prevalence is
!   below or above average contraceptive prevalence
! - Interpolation of abortion rights indices for the years 2010, 2012, 2014 and 2016
! - Update of government effectiveness indicator using QoD data
!	(see ReplicationPackage/code/1_Data_preparation.do for data sources)
!
!
! Variables contained in the data set for analysis WR_finaldata.dta are 
! summarized in WR_finaldata_description.xlsx
!
!
! Generation of dataset
!
!   (1) DATA MERGE: Run 
!
! - ReplicationPackage/data/rawdata/abortion raw data/panel_new.R
!        - Input files: 
!	    - ReplicationPackage/rawdata/abortion raw data/2011_WPPDataset_ReproductiveHealthFamilyPlanning .xls
!	    - ReplicationPackage/rawdata/abortion raw data/2013_WPPDataset_ReproductiveHealthFamilyPlanning.xls
!	    - ReplicationPackage/rawdata/abortion raw data/2015_WPPDataset_Fertility_FP_RH.xls
!	    - ReplicationPackage/rawdata/abortion raw data/undesa_pd_2017_abortion_laws_policies_country_dataset.xlsx
!        - Output file: ReplicationPackage/rawdata/country_panel_abortion_2011-2017.dta
!
! - ReplicationPackage/code/1_Data_preparation.do
!        - Input files: 
!	    - ReplicationPackage/rawdata/data_boyle_et_al_2015.dta 
!	    - ReplicationPackage/rawdata/WBL1971-2022 Dataset.dta
!	    - ReplicationPackage/rawdata/Data_Extract_From_World_Development_Indicators.xlsx
!	    - ReplicationPackage/rawdata/lied_v5.2.xls
!	    - ReplicationPackage/rawdata/24340-0001-Data.dta
!	    - ReplicationPackage/rawdata/ReligiousGroupsWide_v1.02.csv
!	    - ReplicationPackage/rawdata/unpopulation_dataportal_20221112104252.csv
!	    - ReplicationPackage/rawdata/data_ebetuerk_2021.dta
!	    - ReplicationPackage/rawdata/EAP_DWAP_SEX_AGE_RT_A-filtered-2022-11-02.dta
!	    - ReplicationPackage/rawdata/country_panel_abortion_2011-2017.dta
!	    - ReplicationPackage/rawdata/qog_std_ts_jan22.dta
!        - Output file: ReplicationPackage/WR_dataset.dta
!
!   (2) GENERATION OF VARIABLES FOR ANALYSIS: Run
!
! - ReplicationPackage/code/2_Variables.do
!        - Input file: ReplicationPackage/WR_dataset.dta
!        - Output file: ReplicationPackage/WR_finaldata.dta
!
!
! Analysis (same files as provided in the JEEA replication package)
!
!   (1) STATISTICS AND REGRESSION RESULTS: Run
! 
! -  ReplicationPackage/code/3_Analysis.do
!        - Input file: ReplicationPackage/data/WR_finaldata.dta
! 	 - Output files: All files are saved in ReplicationPackage/output/tables
!             
!
!   (2) FIGURES: Run
!
! - ReplicationPackage/code/4_DataForFigures.do to prepare the input files for figures
!
! - Figure 1: ReplicationPackage/code/3_Figure1.R
!       - Input file: ReplicationPackage/output/figures/Overall_Index.txt
!
! - Figure 3: ReplicationPackage/code/4_Figure3.R 
!       - Input file: ReplicationPackage/output/figures/IndicesOverTime.txt
!
! - Figure 4: ReplicationPackage/code/5_Figure4.R
!       - Input file: ReplicationPackage/output/figures/Overall_Index.txt
!
! - Output files: All resulting figures are saved in 
!         'ReplicationPackage/output/figures' as PDF or .tex files            
!
! ------------------------------------------------------------------------------