# DESCRIPTION --- 

# To-Dos / open issue ---- 
# - [x] check if every country in each year
# - [x] how to categorize incest?  Under Rape.
# - 

# Remarks ---- 
# no State of Palestine in 2011 -> remove Palestine from panel? 
# -> answer: no, interpolate.

# HEADER --- 
rm(list = ls())  # clean environment 
cat("\014")      # clean console
library(dplyr);library(readr);library(readxl);library(tidyr);library(ggplot2);library(ggExtra);library(Hmisc);library(texreg);library(hms)
## Load DATA + FILTER VARIABLES -- 

setwd("/Users/hannusch/Desktop/Marshall Lecture/Data/A_FinalData/Women's Rights Replication/data/abortion raw data/")
library(expss)
library(stringr)
library(sjlabelled)

# year 2011
d2011 <- read_excel("2011_WPPDataset_ReproductiveHealthFamilyPlanning .xls", 
                                                    range = "A2:J200")
d2011 <- d2011[3:198,]
d2011 <- d2011 %>% select(`Country  name`, `Country code`, `Grounds on which abortion is permitted`)
d2011$year <- 2011
d2011 <- rename(d2011,abortion = `Grounds on which abortion is permitted`)

d2011 <- d2011 %>% select(`Country  name`, `Country code`, year, abortion)

d2013 <- read_excel("2013_WPPDataset_ReproductiveHealthFamilyPlanning.xls", 
                  range = "A2:J201")
d2013 <- d2013 %>% select(`Country  name`, `Country code`, `Grounds on which abortion is permitted`)
d2013$year <- 2013
d2013 <- rename(d2013,abortion = `Grounds on which abortion is permitted`)
d2013 <- d2013[3:199,]
d2013 <- d2013 %>% select(`Country  name`, `Country code`, year, abortion)

d2015 <- read_excel("2015_WPPDataset_Fertility_FP_RH.xls", 
                    range = "A2:L201")
d2015 <- d2015 %>% select(`Country  name`, `Country code`, `Legal grounds on which abortion is permitted`)
d2015$year <- 2015
d2015 <- d2015[3:199,]
d2015 <- rename(d2015,abortion = `Legal grounds on which abortion is permitted`)
d2015 <- d2015 %>% select(`Country  name`, `Country code`, year, abortion)


# append 2011, 2013, 2015, 
d <- rbind(d2011, d2013, d2015)

# check if country present in each year. 
d <- d %>% group_by(`Country  name`) %>% mutate(count = n()) %>% ungroup()
#d <- d %>% filter(`Country  name` != "State of Palestine") 

d <- d[,c(-5)]

d$reason_1 <- 0
d$reason_2 <- 0
d$reason_3 <- 0
d$reason_4 <- 0
d$reason_5 <- 0
d$reason_6 <- 0
d$reason_7 <- 0

d$reason_1 <- set_label(d$reason_1, "Mother´s life")
d$reason_2 <- set_label(d$reason_2, "Mother's physical health")
d$reason_3 <- set_label(d$reason_3, "Mother's mental health")
d$reason_4 <- set_label(d$reason_4, "Rape")
d$reason_5 <- set_label(d$reason_5, "Fetal impairment")
d$reason_6 <- set_label(d$reason_6, "Economic and social reasons")
d$reason_7 <- set_label(d$reason_7, "On Demand")

for(i in 1:nrow(d)){
  if (str_detect(d$abortion[i], "1") == TRUE) {
    d$reason_1[i] <- 1}
  if (str_detect(d$abortion[i], "2") == TRUE) {
    d$reason_2[i] <- 1}
  if (str_detect(d$abortion[i], "3") == TRUE) {
    d$reason_3[i] <- 1}
  if (str_detect(d$abortion[i], "4") == TRUE) {
    d$reason_4[i] <- 1}
  if (str_detect(d$abortion[i], "5") == TRUE) {
    d$reason_5[i] <- 1}
  if (str_detect(d$abortion[i], "6") == TRUE) {
    d$reason_6[i] <- 1}
  if (str_detect(d$abortion[i], "7") == TRUE) {
    d$reason_7[i] <- 1}
}

# 2017 Data 

d2017 <- read_excel("undesa_pd_2017_abortion_laws_policies_country_dataset.xlsx", range = "B8:O240")
d2017 <- d2017[,c(-3)]

d2017 <- rename(d2017, `Country  name`=`...1`)
d2017 <- rename(d2017, `Country  code`=`...2`)
d2017$year <- 2017

d2017 <- na.omit(d2017)

d2017$reason_1 <- 0
d2017$reason_2 <- 0
d2017$reason_3 <- 0
d2017$reason_4 <- 0
d2017$reason_5 <- 0
d2017$reason_6 <- 0
d2017$reason_7 <- 0

d2017$reason_1 <- set_label(d2017$reason_1, "Mother´s life")
d2017$reason_2 <- set_label(d2017$reason_2, "Mother's physical health")
d2017$reason_3 <- set_label(d2017$reason_3, "Mother's mental health")
d2017$reason_4 <- set_label(d2017$reason_4, "Rape")
d2017$reason_5 <- set_label(d2017$reason_5, "Fetal impairment")
d2017$reason_6 <- set_label(d2017$reason_6, "Economic and social reasons")
d2017$reason_7 <- set_label(d2017$reason_7, "On Demand")

# enough if one of the subcategories holds. 

d2017$cat_1a <- d2017[,3]
d2017$cat_1b <- d2017[,4]
d2017$cat_1c <- d2017[,5]
d2017$cat_1d <- d2017[,6]
d2017$cat_1e <- d2017[,7]
d2017$cat_1f <- d2017[,8]
d2017$cat_1g <- d2017[,9]
d2017$cat_1h <- d2017[,10]
d2017$cat_1i <- d2017[,11]
d2017$cat_1j <- d2017[,12]
d2017$cat_1k <- d2017[,13]
d2017 <- d2017[,-c(3:13)]

# Reason 1) Mother's life
# d2017$`1.a. To save a woman's life`
d2017$reason_1[d2017$cat_1a =="Yes"] <- 1

# Reason 2) Mother's physical health
# d2017$`1.b.To preserve a woman's health`
# d2017$`1.c. To preserve a woman's physical health`
d2017$reason_2[d2017$cat_1b =="Yes" | d2017$cat_1c =="Yes" ] <- 1

test <- d2017 %>% select(`Country  name`, year, reason_2, cat_1b, cat_1c)

# Reason 3) Mother's mental health
# d2017$`1.d. To preserve a woman's mental health`
# d2017$`1.e.In cases of intellectual or cognitive disability of the woman`
d2017$reason_3[d2017$cat_1d =="Yes" | d2017$cat_1e =="Yes" ] <- 1

# Reason 4) Rape
# d2017$`1.g. In cases of rape`
# d2017$`1.f. In cases of incest` 
d2017$reason_4[d2017$cat_1g =="Yes" | d2017$cat_1f =="Yes" ] <- 1

# Reason 5) Fetal impairment
# d2017$`1.h. In cases of foetal impairment`
d2017$reason_5[d2017$cat_1h =="Yes"  ] <- 1

# Reason 6) Economic and social reasons (e.g.  if they already have x number of children, i.e. family size too big)
# d2017$`1.i. For economic or social reasons`
d2017$reason_6[d2017$cat_1i =="Yes"] <- 1

# Reason 7) On demand & other legal grounds
# d2017$`1.j. On request`
# d2017$`1.k. Other legal grounds`
d2017$reason_7[d2017$cat_1j =="Yes" | d2017$cat_1k =="Yes"] <- 1

d2017 <- d2017 %>% select(`Country  name`, `Country  code`, year, starts_with("reason_"))

# append with other countries and check if country present in each year

d <- d %>% select(`Country  name`, `Country code`, year, starts_with("reason_"))
d2017 <- rename(d2017, `Country code` = `Country  code`)

d <- rbind(d,d2017)

# Replace a few country names for compatibility reasons: 
d$`Country  name`[d$`Country  name`== "Micronesia (Fed. States of)"] <- "Micronesia (Federated States of)"
d$`Country  name`[d$`Country  name`== "Czechia"] <- "Czech Republic"

d$`Country  name`[d$`Country  name`== "Dem. People's Republic of Korea"] <- "Democratic People's Republic of Korea"
d$`Country  name`[d$`Country  name`== "The former Yugoslav Rep. of Macedonia"] <- "North Macedonia"
d$`Country  name`[d$`Country  name`== "Swaziland"] <- "Eswatini"
#d <- d %>% filter(`Country  name` != "State of Palestine") 

d <- d %>% group_by(`Country  name`) %>% mutate(count = n()) %>% ungroup()


# ----------------------
# Add Palestine for 2011 
d[nrow(d) + 1,] <- list("State of Palestine", "275", 2011, 1, 0 ,0,0,0,0,0, 0)

d <- d[,-c(11)]

d <- rename(d,country=`Country  name`)
# ----------------------

# export data: 
library("writexl")
write_xlsx(d,"/Users/hannusch/Desktop/Marshall Lecture/Data/A_FinalData/Women's Rights Replication/data/country_panel_abortion_2011-2021.xlsx")

library(foreign)
write.dta(d, "/Users/hannusch/Desktop/Marshall Lecture/Data/A_FinalData/Women's Rights Replication/data/country_panel_abortion_2011-2021.dta")

